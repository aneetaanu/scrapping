<!--<div id="res"></div>
<textarea rows="5" cols="45" id="link" required placeholder="Insert the url"></textarea><br>
<button id="btn" type="button">EXTRACT DATA</button>



<form method="post" name="scrap_form" id="scrap_form" action="scrap.php" >
<label>Enter Website URL To Scrape Data</label>
<input type="input" name="website_url" id="website_url">
<input type="submit" name="submit" value="Submit" >
</form>-->


<?php 





include('simple_html_dom.php');
$html = file_get_html('https://streamango.tv/putlockers/');
//to fetch all hyperlinks from a webpage

foreach($html->find('div.ml-item') as $item){
//echo  $item->plaintext.'\n';
}

$links = array();
foreach($html->find('a') as $a) {
 $links[] = $a->href;
}



$images = array();
foreach($html->find('img') as $img) {
	//print_r($img);
  echo $images[] = $img->src;
}


$headlines = array();
foreach($html->find('href') as $header) {
 $headlines[] = $header->plaintext;
}


echo '<pre>';
print_r($links);
print_r($headlines);
print_r($images);
echo '</pre>';
foreach($html->find('div.ml-item a') as $anchor) 
{
echo $anchor->attr['href']." & oldtitle= ";
echo ($anchor->find('h1')->plaintext);
}